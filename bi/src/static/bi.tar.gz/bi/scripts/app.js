/**
 * Register the 'demo' angular module here in a global namespace.
 *
 */
angular.module('modeApp', [
    'ui.router',
    'ngCookies'
]);